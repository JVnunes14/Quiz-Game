# C# Multiple Choice Quiz Game Tutorial
In this project we will makea  simple quiz game in windows form. This will be a multiple choice game where you are asked a question and you have 4 variations of answers on the screen. You can use images or just text to make the quizes and you can use this a template for your own application in Visual Studio. 

Video Tutorial - 

[![](http://img.youtube.com/vi/hQDjz2ISklw/0.jpg)](http://www.youtube.com/watch?v=hQDjz2ISklw "MOO ICT c sharp multiple choice quiz game")



link

https://www.mooict.com/c-tutorial-create-a-simple-multiple-choice-quiz-game-in-visual-studio/
